﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Пример пути: C:\\\\Users\\\\user\\\\Documents\\\\test.txt");

            Console.Write("\nВведите абсолютный путь к файлу: ");
            string absolutePath = Console.ReadLine();
            // string absolutePath = @"C:Users\Danya\Downloads\Билетексы.docx";



            FileInfo fileInfo = new FileInfo(absolutePath);
            DirectoryInfo directoryInfo = new DirectoryInfo(Convert.ToString(fileInfo.Directory.FullName));

            List<string> pathParts = new List<string>();
            // pathParts[индекс]
            int i = 1;

        
            if (fileInfo.Exists)
            {
                Console.WriteLine($"\nИмя файла: {fileInfo.Name}");
                pathParts.Add(fileInfo.Name);

                //Console.WriteLine($"Имя директории: {fileInfo.Directory.Name}");
                //Console.WriteLine(fileInfo.Directory.Parent.Name);
                //Console.WriteLine(fileInfo.Directory.Parent.Parent.Parent.Parent);

                while (true)
                {

                    if (directoryInfo.Exists && directoryInfo.Parent != null)
                    {
                        pathParts.Add(directoryInfo.Name);

                        Console.WriteLine($"Директория №{i++}: {directoryInfo.Name}");
                        directoryInfo = directoryInfo.Parent;
                    } else if (directoryInfo.Exists && directoryInfo.Parent == null)
                    {
                        pathParts.Add(directoryInfo.Name);

                        Console.WriteLine($"Диск: {directoryInfo.Name}");
                        break;
                    }
                }


                // Поменять расширение файла на новое
                Console.WriteLine("\nПример расширения: jpg, doc, mp3 (без точки в начале)");
                Console.Write("Введите новое расширение файла: ");
                string extension = Console.ReadLine();

                // Переименование + обновление пути
                fileInfo.MoveTo(Path.ChangeExtension(absolutePath, $".{extension}"));
                Console.WriteLine($"\nНовый путь к файлу (расширение): {fileInfo.FullName}");


                // Перемещение файла в корневой каталог
                // Отказ в доступе к диску C
                // fileInfo.MoveTo(pathParts[pathParts.Count-1] + fileInfo.Name);



                // Перемещение между C:\\Users\\Danya\\Downloads\\ и D:\
                

                if (fileInfo.Directory.Root.ToString() == "C:\\")
                {
                    fileInfo.MoveTo($"D:\\{fileInfo.Name}");
                    Console.WriteLine($"\nНовый путь к файлу: {fileInfo.FullName}\n");
                }
                else
                {
                    fileInfo.MoveTo($"C:\\Users\\Danya\\Downloads\\{fileInfo.Name}");
                    Console.WriteLine($"\nНовый путь к файлу (корневой каталог): {fileInfo.FullName}\n");
                }
                

                // Console.WriteLine(fileInfo.Directory.Root);
            }
            else
            {
                Console.WriteLine("Такого файла нет!");
            }
        }
    }
}